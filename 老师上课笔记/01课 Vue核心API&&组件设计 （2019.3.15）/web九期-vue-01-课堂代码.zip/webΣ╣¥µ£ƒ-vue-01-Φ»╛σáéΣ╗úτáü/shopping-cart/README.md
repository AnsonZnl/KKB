### 步骤

- 环境：vue-cli3         node 8.10+

- 进入项目后 执行 npm install

- 执行 npm run serve