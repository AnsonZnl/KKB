### 步骤

- 环境：vue-cli3         node 8.10+



- 打开项目 进入项目目录
- 执行 npm install
- 执行 vue add element 
- 然后 npm run serve