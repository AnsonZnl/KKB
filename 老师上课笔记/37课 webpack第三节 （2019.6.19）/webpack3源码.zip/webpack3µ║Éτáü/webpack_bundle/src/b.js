const b = 10;

export default b;
