const a = 10;

export default a;
