module.exports = function(source) {
  return source.replace("kkb", "word");
};
