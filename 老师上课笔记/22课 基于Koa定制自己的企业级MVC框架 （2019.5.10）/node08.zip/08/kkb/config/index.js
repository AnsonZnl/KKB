module.exports = {
    db: {
        dialect: 'mysql',
        host: 'localhost',
        database: 'test',
        username: 'root',
        password: 'example'
    },
    middleware: ['logger']
}