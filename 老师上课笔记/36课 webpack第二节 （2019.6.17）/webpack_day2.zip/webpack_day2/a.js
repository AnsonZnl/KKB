export const add = (a, b) => {
  console.log(a + b);
};

export const minus = (a, b) => {
  console.log(a - b);
};

// function a() {
//   var div = document.createElement("div");
//   div.setAttribute("id", "number");
//   div.innerHTML = 10000;
//   document.body.appendChild(div);
// }

// export default a;
