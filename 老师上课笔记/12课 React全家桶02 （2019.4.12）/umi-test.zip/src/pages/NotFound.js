import styles from "./NotFound.css";

export default function() {
  return (
    <div className={styles.normal}>
      <h1>Page NotFound, 404</h1>
    </div>
  );
}
