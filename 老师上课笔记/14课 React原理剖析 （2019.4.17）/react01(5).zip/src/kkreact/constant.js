/*
  常量
*/
export const HTML_KEY = 'dangerouslySetInnerHTML'
export const COMPONENT_ID = 'kkbid'
export const VTEXT = 1
export const VELEMENT = 2
export const VSTATELESS = 3
export const VCOMPONENT = 4


export const CREATE = 1
export const REMOVE = 2
export const UPDATE = 3
export const ELEMENT_NODE_TYPE = 1
