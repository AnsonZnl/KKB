module.exports = {
  SECRET: 'xxxx', // 小程序 secret id
  TEMPLATE_ID: 'xxxxx' // 模板 id
};