import Taro, { Component } from '@tarojs/taro'
import { View, Button, Text, Swiper, SwiperItem  } from '@tarojs/components'

export default class KSwiper extends Component {
  componentDidMount(){

    let res = this.props
    console.log(res)
    // console.log([res.slice(0, 3), res.slice(3, 6), res.slice(6)])
    // return [res.slice(0, 3), res.slice(3, 6), res.slice(6)]
  }
  render(){
return <View class='swiper'>
123
{/* <Swiper12
  :indicator-dots='true'
  indicator-color='#EA5A49'
  :autoplay='true'
  :interval='6000'
  :duration='1000'
  :circular='true'
>
  <div :key='imgindex' v-for='(top,imgindex) in imgUrls'>
    <SwiperItem>
      <img  
        @click='bookDetail(img)'
        class='slide-image' 
        mode='aspectFit' 
        v-for='img in top'
        :key='img.id'
        :src="img.image" 
        >
    </SwiperItem>
  </div>

</Swiper> */}
</View>
  }
}