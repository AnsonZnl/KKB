export default class NavigatorBriage {}
