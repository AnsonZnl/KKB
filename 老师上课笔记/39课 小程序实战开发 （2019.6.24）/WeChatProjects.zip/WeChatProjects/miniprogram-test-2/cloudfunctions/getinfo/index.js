// 云函数入口文件
const cloud = require('wx-server-sdk')

cloud.init()
// 这是node项目
// 爬虫
// 登录
// 网络数据
// 读云数据库等
// 云函数入口函数
// 加法
exports.main = async (event, context) => {
  return {
    sum: event.a + event.b
  }
}