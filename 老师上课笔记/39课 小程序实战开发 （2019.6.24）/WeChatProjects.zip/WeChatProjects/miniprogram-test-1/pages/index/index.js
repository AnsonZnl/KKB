// //index.js
// //获取应用实例

// const app = getApp()

// Page({
//   onReady(e) {
//     // 使用 wx.createAudioContext 获取 audio 上下文 context
//     this.audioCtx = wx.createAudioContext('myAudio')
//   },
//   data: {
//     poster: 'http://y.gtimg.cn/music/photo_new/T002R300x300M000003rsKF44GyaSk.jpg?max_age=2592000',
//     name: '此时此刻',
//     author: '许巍',
//     src: 'http://ws.stream.qqmusic.qq.com/M500001VfvsJ21xFqb.mp3?guid=ffffffff82def4af4b12b3cd9337d5e7&uin=346897220&vkey=6292F51E1E384E06DCBDC9AB7C49FD713D632D313AC4858BACB8DDD29067D3C601481D36E62053BF8DFEAF74C0A5CCFADD6471160CAF3E6A&fromtag=46',
//   },
//   audioPlay() {
//     this.audioCtx.play()
//   },
//   audioPause() {
//     this.audioCtx.pause()
//   },
//   audio14() {
//     this.audioCtx.seek(14)
//   },
//   audioStart() {
//     this.audioCtx.seek(0)
//   }
// })
// const kkb = require('../../utils/kkb.js')
const db = wx.cloud.database({
  env:"kaikeba-64cf41"
})
// 获取数据库的实例
Page({
  onLoad(){
    console.log('加载')
      db.collection('counters')
        .get({
          success(res){
            console.log(res.data)
          }
        })
    // console.log('初始化生命周期')
    // wx.request({
    //   url: kkb.urlPrefix + '/test',
    //   success:res=>{
    //     console.log(res)
    //   }
    // })

  },
  toast(){
    wx.showToast({
      title:'成功信息',
      icon:'success',
      duration:3000
    })
  }
})
// Page({
//   data:{
//     age:18,
//     val:"",
//     src:"",
//     todos:['吃饭','睡觉','开课吧学习']
//   },
//   handleInput(e){
//     // 模拟react的setState
//     this.setData({
//       val:e.detail.value,
//     })
//     // console.log(e.detail)
//   },
//   addTodo(){
//     this.setData({
//       val:'',
//       todos:[...this.data.todos, this.data.val]
//     })
//   },
//   takePhoto(){
//     // 摄像头上下文
//     const ctx = wx.createCameraContext()
//     ctx.takePhoto({
//       quality:'high',
//       success:res=>{
//         this.setData({
//           src:res.tempImagePath
//         })
//       }
//     })
//   }
// })

// Page({
//   data: {
//     motto: 'Hello World',
//     userInfo: {},
//     hasUserInfo: false,
//     canIUse: wx.canIUse('button.open-type.getUserInfo')
//   },
//   //事件处理函数
//   bindViewTap: function() {
//     wx.navigateTo({
//       url: '../logs/logs'
//     })
//   },
//   onLoad: function () {
//     if (app.globalData.userInfo) {
//       this.setData({
//         userInfo: app.globalData.userInfo,
//         hasUserInfo: true
//       })
//     } else if (this.data.canIUse){
//       // 由于 getUserInfo 是网络请求，可能会在 Page.onLoad 之后才返回
//       // 所以此处加入 callback 以防止这种情况
//       app.userInfoReadyCallback = res => {
//         this.setData({
//           userInfo: res.userInfo,
//           hasUserInfo: true
//         })
//       }
//     } else {
//       // 在没有 open-type=getUserInfo 版本的兼容处理
//       wx.getUserInfo({
//         success: res => {
//           app.globalData.userInfo = res.userInfo
//           this.setData({
//             userInfo: res.userInfo,
//             hasUserInfo: true
//           })
//         }
//       })
//     }
//   },
//   getUserInfo: function(e) {
//     console.log(e)
//     app.globalData.userInfo = e.detail.userInfo
//     this.setData({
//       userInfo: e.detail.userInfo,
//       hasUserInfo: true
//     })
//   }
// })
