module.exports = {

  urlPrefix:'http://localhost:3000'
}